title('Reminder');

visualHints('Say "How should I use this"','Say "What does this app do"', 'Say "How does this works"')

intent('How should I use this', 'What does this app do', 'How does this works', p=>{
    p.play('This application is for adding reminders and setting timer')
    p.play('say "remind for that I have work"')
})

let reminderRequests = [
	"(set|add|make) a reminder at $(DATE) $(TIME) for $(TEXT* (.*))",
	"remind me at $(DATE) $(TIME) for $(TEXT* (.*))",
	"remind me that $(TEXT* (.*))",

];



intent(reminderRequests, p =>
{

	const convertTime12to24 = (time12h) =>
	{
		const [time, modifier] = time12h.split(' ');
		let [hours, minutes] = time.split(':');
		if (hours === '00')
		{
			hours = time
		}
		if (minutes == undefined)
		{
			minutes = '00'
		}
		if (hours === '12')
		{
			hours = '00';
		}

		if (modifier === 'p.m')
		{
			hours = parseInt(hours, 10) + 12;
		}

		return `${hours}:${minutes}`;
	}
	if (p.DATE == undefined)
	{
		p.play(`Sure, ${p.TEXT.value}`)
		p.play(
		{
			command: 'setReminder',
			time: 'No time',
			text: p.TEXT.value
		});
	}
	else
	{
		p.play(`Ok setting reminder at ${p.TIME.value} on ${p.DATE.moment.format("MMM Do")} for ${p.TEXT.value}`);
		p.play(
		{
			command: 'setReminder',
			time: p.DATE.moment.format("MM:DD:YYYY") + convertTime12to24(p.TIME.value),
			text: p.TEXT.value
		});
	}
});




let delContext = context(() =>
{
	follow("yes", p =>
	{
		p.play(`You have deleted ${p.state.text}`);
		p.play(
		{
			command: 'delReminder',
			text: p.state.text
		});
	});
	follow("no", p =>
	{
		p.play(`cancel`);

	});
});

intent('delete last reminder', p =>
{

	p.play(
	{
		command: 'lReminder'
	})

})

intent("(delete|cancel|remove) a reminder for $(TEXT* (.*))','(delete|cancel|remove) the $(TEXT* (.*)) reminder", p =>
{
	if (!p.TEXT)
	{
		p.play('Sorry, I can not delete reminder for empty text')
	}
	else
	{
		p.state.text = p.TEXT.value;

		p.play(`Sure, do you confirm to delete ${p.TEXT.value}`);
		p.then(delContext,
		{
			state: p.state
		});
	}
});




let confirmReminder = context(() =>
{
	follow('yes', p =>
	{
		p.play(
		{
			command: 'clrReminders'
		})
		p.play('removing all reminders')
	});

	follow('no', p =>
	{
		p.play('cancelled');
	});
});


intent('(cancel|remove| delete) all reminders', p =>
{
	p.play(`You have clearing all reminders. Do you confirm?`);
	p.then(confirmReminder);
});

title('Timer')

let resumeTimer = context(() =>
{
	follow('resume (the timer|)', p =>
	{

		p.play(
		{
			command: 'resumeTimer'
		})
		p.play('Resuming the timer')


	});

	follow('reset (the timer|)', p =>
	{
		p.play(
		{
			command: 'resetTimer'
		})
		p.play('ok! Done');

	});
});

let stopTimer = context(() =>
{
	follow('stop (the timer|)', p =>
	{

		p.play(
		{
			command: 'stopTimer'
		})
		p.play('Stoppinging timer')
		p.then(resumeTimer)

	});

	follow('no', p =>
	{
		p.play('ok! cancelled');
	});
});




let startTimer = context(() =>
{
	follow('yes', p =>
	{
		p.play(
		{
			command: 'startTimer'
		})

		p.play('Starting timer')
		p.then(stopTimer)
	});

	follow('no', p =>
	{
		p.play('ok! cancelled');
	});
});




intent('set timer for $(NUMBER) (hour_) $(MM NUMBER) (minute_) and $(SS NUMBER) (second_)', 'set timer for $(MM NUMBER) (minute_) and $(SS NUMBER) (second_)', ' set timer for $(MM NUMBER) minutes', ' set timer for $(SS NUMBER) seconds', p =>
{
	


	//     p.state.hour = p.NUMBER.value;
	//     p.state.mim = p.MM.value;
	//     p.state.sec = p.SS.value;

	p.play(
	{
		command: 'setTimer',
		hour: p.NUMBER == undefined ? '00': p.NUMBER.value,
		minutes: p.MM == undefined ? '00' :p.MM.value,
		seconds: p.SS == undefined ? '00': p.SS.value
	})
    p.play(`ok setting timer`)
	p.play('Do you want to start timer')
	p.then(startTimer);
})


intent('(go to|) timer (screen|page)', p =>
{
	p.play(
	{
		command: 'goTimerpage'
	})
	p.play('you are being directed to timer screen')
})


projectAPI.greet = (p, param, callback) =>
{
	p.play("Welcome to the Reminder for make reminds and set timer. (How can I help you|What can I do for you)?");
};